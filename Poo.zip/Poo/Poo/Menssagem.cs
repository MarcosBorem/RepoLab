﻿using System;

namespace Poo
{
    class Menssagem
    {
        public string TextoMensagem { get; set; }
        public void ExibirMensagem()
        {
            Console.WriteLine(TextoMensagem);
        }
    }

    
}
